require('mootools');
require('./src');
