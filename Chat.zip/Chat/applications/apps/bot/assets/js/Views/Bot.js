Package('Bot.Views', {
	 Bot : new  Class({
		Extends: Sapphire.View,

		initialize : function()
		{
			this.parent();
		}
	})
});
