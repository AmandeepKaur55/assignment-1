Package('Setup.Views', {
	Help : new Class({
		Extends : Sapphire.View,

		initialize : function()
		{
			this.parent();
		},

		draw : function()
		{
		}
	})
});
